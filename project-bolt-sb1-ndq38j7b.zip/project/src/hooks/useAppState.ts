import { useEffect, useState } from 'react';
import { createSampleState } from '@/lib/sampleData';
import { loadState, saveState } from '@/lib/storage';
import type { AppState, AttendanceInput, SessionInput, TaskInput } from '@/types';

function createId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

export function useAppState() {
  const [state, setState] = useState<AppState>(loadState);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const addTask = (input: TaskInput) =>
    setState(prev => ({ ...prev, tasks: [...prev.tasks, { ...input, id: createId(), completed: false }] }));

  const toggleTask = (id: string) =>
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(task => (task.id === id ? { ...task, completed: !task.completed } : task)),
    }));

  const deleteTask = (id: string) =>
    setState(prev => ({ ...prev, tasks: prev.tasks.filter(task => task.id !== id) }));

  const saveAttendance = (id: string | null, input: AttendanceInput) =>
    setState(prev => ({
      ...prev,
      attendance: id
        ? prev.attendance.map(record => (record.id === id ? { ...record, ...input } : record))
        : [...prev.attendance, { ...input, id: createId() }],
    }));

  const deleteAttendance = (id: string) =>
    setState(prev => ({ ...prev, attendance: prev.attendance.filter(record => record.id !== id) }));

  const setTargetPercent = (targetPercent: number) => setState(prev => ({ ...prev, targetPercent }));

  const addSession = (input: SessionInput) =>
    setState(prev => ({ ...prev, sessions: [...prev.sessions, { ...input, id: createId() }] }));

  const deleteSession = (id: string) =>
    setState(prev => ({ ...prev, sessions: prev.sessions.filter(session => session.id !== id) }));

  const resetDemo = () => setState(createSampleState());

  return {
    state,
    addTask,
    toggleTask,
    deleteTask,
    saveAttendance,
    deleteAttendance,
    setTargetPercent,
    addSession,
    deleteSession,
    resetDemo,
  };
}
