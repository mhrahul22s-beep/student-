import { useCallback, useState } from 'react';

export interface Toast {
  id: number;
  message: string;
}

const MAX_VISIBLE_TOASTS = 3;

export function useToasts() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback((id: number) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  }, []);

  const notify = useCallback((message: string) => {
    setToasts(prev => [...prev, { id: Date.now() + Math.random(), message }].slice(-MAX_VISIBLE_TOASTS));
  }, []);

  return { toasts, notify, dismiss };
}
