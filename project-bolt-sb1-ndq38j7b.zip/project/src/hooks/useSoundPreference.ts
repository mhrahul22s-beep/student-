import { useEffect, useState } from 'react';

const STORAGE_KEY = 'campuspilot-sound-enabled';

function readSoundPreference(): boolean {
  try {
    return window.localStorage.getItem(STORAGE_KEY) !== 'off';
  } catch {
    return true;
  }
}

export function useSoundPreference() {
  const [enabled, setEnabled] = useState<boolean>(readSoundPreference);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, enabled ? 'on' : 'off');
    } catch {
      // Storage unavailable: the preference lasts only for this page visit.
    }
  }, [enabled]);

  const toggle = () => setEnabled(prev => !prev);

  return { enabled, toggle };
}
