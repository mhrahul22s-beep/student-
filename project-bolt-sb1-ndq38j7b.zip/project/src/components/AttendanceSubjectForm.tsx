import { useState, type FormEvent } from 'react';
import { Button, Field, inputClass } from '@/components/ui';
import { validateAttendanceInput } from '@/lib/attendance';
import type { AttendanceInput } from '@/types';
import type { AttendanceRecord } from '@/types';

interface Props {
  initial: AttendanceRecord | null;
  subjects: string[];
  onSubmit: (input: AttendanceInput) => void;
  onCancel: () => void;
}

export default function AttendanceSubjectForm({ initial, subjects, onSubmit, onCancel }: Props) {
  const [subject, setSubject] = useState(initial?.subject ?? '');
  const [attended, setAttended] = useState(initial ? String(initial.attended) : '');
  const [total, setTotal] = useState(initial ? String(initial.total) : '');
  const [subjectError, setSubjectError] = useState<string>();
  const [countErrors, setCountErrors] = useState<{ attended?: string; total?: string }>({});

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const name = subject.trim();
    const nameError = name ? undefined : 'Enter a subject name.';
    const counts = validateAttendanceInput(attended, total);
    setSubjectError(nameError);
    setCountErrors(counts.ok ? {} : counts.errors);
    if (nameError || !counts.ok) return;
    onSubmit({ subject: name, attended: counts.attended, total: counts.total });
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-4">
      <Field label="Subject" htmlFor="att-subject" error={subjectError}>
        <input
          id="att-subject"
          list="attendance-subject-options"
          className={inputClass}
          placeholder="e.g. Engineering Physics"
          value={subject}
          onChange={event => {
            setSubject(event.target.value);
            setSubjectError(undefined);
          }}
        />
        <datalist id="attendance-subject-options">
          {subjects.map(option => (
            <option key={option} value={option} />
          ))}
        </datalist>
      </Field>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Classes attended" htmlFor="att-attended" error={countErrors.attended}>
          <input
            id="att-attended"
            type="number"
            inputMode="numeric"
            min={0}
            className={inputClass}
            value={attended}
            onChange={event => {
              setAttended(event.target.value);
              setCountErrors(prev => ({ ...prev, attended: undefined }));
            }}
          />
        </Field>
        <Field label="Total classes held" htmlFor="att-total" error={countErrors.total}>
          <input
            id="att-total"
            type="number"
            inputMode="numeric"
            min={1}
            className={inputClass}
            value={total}
            onChange={event => {
              setTotal(event.target.value);
              setCountErrors(prev => ({ ...prev, total: undefined }));
            }}
          />
        </Field>
      </div>
      <div className="flex flex-col-reverse gap-3 pt-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">{initial ? 'Save changes' : 'Add subject'}</Button>
      </div>
    </form>
  );
}
