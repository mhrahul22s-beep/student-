import { CalendarDays, ClipboardList, GraduationCap, LayoutDashboard, RotateCcw, UserCheck, Volume2, VolumeX, type LucideIcon } from 'lucide-react';
import type { View } from '@/types';

const NAV_ITEMS: { view: View; label: string; icon: LucideIcon }[] = [
  { view: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { view: 'assignments', label: 'Assignments', icon: ClipboardList },
  { view: 'attendance', label: 'Attendance', icon: UserCheck },
  { view: 'planner', label: 'Study planner', icon: CalendarDays },
];

function Logo() {
  return (
    <div className="flex items-center gap-3">
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-500 text-navy-950 shadow-lg shadow-teal-500/20">
        <GraduationCap className="h-5 w-5" />
      </span>
      <div>
        <p className="text-base font-bold text-white">CampusPilot</p>
        <p className="text-xs text-navy-200">First-year engineering</p>
      </div>
    </div>
  );
}

interface NavProps {
  active: View;
  onChange: (view: View) => void;
}

interface SoundProps {
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export function Sidebar({ active, onChange, onReset, soundEnabled, onToggleSound }: NavProps & SoundProps & { onReset: () => void }) {
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col bg-navy-950 px-4 py-6 lg:flex">
      <div className="px-2">
        <Logo />
      </div>
      <nav className="mt-10 flex flex-col gap-1" aria-label="Main navigation">
        {NAV_ITEMS.map(item => {
          const isActive = item.view === active;
          const Icon = item.icon;
          return (
            <button
              key={item.view}
              type="button"
              onClick={() => onChange(item.view)}
              aria-current={isActive ? 'page' : undefined}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition duration-200 ${
                isActive ? 'bg-teal-500/15 text-teal-300 ring-1 ring-teal-400/30' : 'text-navy-200 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </button>
          );
        })}
      </nav>
      <div className="mt-auto space-y-3 border-t border-white/10 pt-4">
        <p className="px-2 text-xs text-navy-300">Your data is saved in this browser.</p>
        <button
          type="button"
          onClick={onToggleSound}
          aria-pressed={soundEnabled}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-navy-200 transition hover:bg-white/5 hover:text-white"
        >
          {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          Sound {soundEnabled ? 'On' : 'Off'}
        </button>
        <button
          type="button"
          onClick={onReset}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-navy-200 transition hover:bg-white/5 hover:text-white"
        >
          <RotateCcw className="h-4 w-4" />
          Reset demo data
        </button>
      </div>
    </aside>
  );
}

export function MobileHeader({ onReset, soundEnabled, onToggleSound }: { onReset: () => void } & SoundProps) {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between bg-navy-950 px-4 py-3 lg:hidden">
      <Logo />
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={onToggleSound}
          aria-pressed={soundEnabled}
          aria-label={soundEnabled ? 'Turn sound off' : 'Turn sound on'}
          className="rounded-xl p-2 text-navy-200 transition hover:bg-white/10 hover:text-white"
        >
          {soundEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
        </button>
        <button
          type="button"
          onClick={onReset}
          aria-label="Reset demo data"
          className="rounded-xl p-2 text-navy-200 transition hover:bg-white/10 hover:text-white"
        >
          <RotateCcw className="h-5 w-5" />
        </button>
      </div>
    </header>
  );
}

export function MobileNav({ active, onChange }: NavProps) {
  return (
    <nav
      aria-label="Main navigation"
      className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-4 border-t border-white/10 bg-navy-950 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2 lg:hidden"
    >
      {NAV_ITEMS.map(item => {
        const isActive = item.view === active;
        const Icon = item.icon;
        return (
          <button
            key={item.view}
            type="button"
            onClick={() => onChange(item.view)}
            aria-current={isActive ? 'page' : undefined}
            className={`flex flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] font-medium transition ${
              isActive ? 'text-teal-300' : 'text-navy-200 hover:text-white'
            }`}
          >
            <Icon className={`h-5 w-5 transition-transform duration-200 ${isActive ? 'scale-110' : ''}`} />
            {item.label}
          </button>
        );
      })}
    </nav>
  );
}
