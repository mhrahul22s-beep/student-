import { useState } from 'react';
import { Calculator } from 'lucide-react';
import { Card, Field, ProgressBar, inputClass } from '@/components/ui';
import { attendancePercent, classesCanMiss, classesNeededToReach, getAttendanceAdvice, getAttendanceStatus, STATUS_META, validateAttendanceInput } from '@/lib/attendance';

interface Props {
  target: number;
}

export default function AttendanceCalculator({ target }: Props) {
  const [attended, setAttended] = useState('');
  const [total, setTotal] = useState('');

  const bothEmpty = attended.trim() === '' && total.trim() === '';
  const validation = bothEmpty ? null : validateAttendanceInput(attended, total);
  const result = validation?.ok ? validation : null;
  const errors = validation && !validation.ok ? validation.errors : {};

  const percent = result ? attendancePercent(result.attended, result.total) : null;
  const status = result ? getAttendanceStatus(result.attended, result.total, target) : 'empty';
  const needed = result ? classesNeededToReach(result.attended, result.total, target) : null;
  const canMiss = result ? classesCanMiss(result.attended, result.total, target) : 0;

  return (
    <Card className="h-fit">
      <div className="mb-5 flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-navy-100 text-navy-700">
          <Calculator className="h-5 w-5" />
        </span>
        <div>
          <h2 className="text-lg font-semibold text-navy-900">Quick calculator</h2>
          <p className="text-sm text-slate-500">Check any subject without saving it.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Field label="Attended" htmlFor="calc-attended" error={errors.attended}>
          <input
            id="calc-attended"
            type="number"
            inputMode="numeric"
            min={0}
            className={inputClass}
            placeholder="0"
            value={attended}
            onChange={event => setAttended(event.target.value)}
          />
        </Field>
        <Field label="Total held" htmlFor="calc-total" error={errors.total}>
          <input
            id="calc-total"
            type="number"
            inputMode="numeric"
            min={1}
            className={inputClass}
            placeholder="0"
            value={total}
            onChange={event => setTotal(event.target.value)}
          />
        </Field>
      </div>

      <div className="mt-6 rounded-xl bg-slate-50 p-4" aria-live="polite">
        {result && percent !== null ? (
          <div className="space-y-4">
            <div className="flex items-end justify-between">
              <p className="text-3xl font-bold text-navy-900">{percent.toFixed(1)}%</p>
              <p className={`text-sm font-semibold ${STATUS_META[status].text}`}>{STATUS_META[status].label}</p>
            </div>
            <ProgressBar label="Calculated attendance" value={percent} tone={STATUS_META[status].tone} track="bg-slate-200" />
            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="rounded-lg bg-white p-3 ring-1 ring-slate-200">
                <p className="text-xl font-bold text-navy-900">{needed === null ? '--' : needed}</p>
                <p className="text-xs text-slate-500">Classes needed</p>
              </div>
              <div className="rounded-lg bg-white p-3 ring-1 ring-slate-200">
                <p className="text-xl font-bold text-navy-900">{canMiss}</p>
                <p className="text-xs text-slate-500">Classes you can miss</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-slate-600">{getAttendanceAdvice(result.attended, result.total, target)}</p>
          </div>
        ) : (
          <p className="text-sm text-slate-500">Enter the classes attended and the total held to see your result.</p>
        )}
      </div>
    </Card>
  );
}
