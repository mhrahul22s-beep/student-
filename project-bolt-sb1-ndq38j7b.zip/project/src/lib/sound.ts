const CHIME_NOTES = [523.25, 659.25, 783.99];
const NOTE_SPACING_S = 0.08;
const NOTE_LENGTH_S = 0.35;
const PEAK_GAIN = 0.1;
const CLOSE_AFTER_MS = 1200;

export function playCompletionChime(): void {
  try {
    const AudioContextCtor =
      window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor) return;

    const ctx = new AudioContextCtor();
    if (ctx.state === 'suspended') void ctx.resume();
    const now = ctx.currentTime;

    CHIME_NOTES.forEach((frequency, index) => {
      const start = now + index * NOTE_SPACING_S;
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(PEAK_GAIN, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + NOTE_LENGTH_S);
      oscillator.connect(gain).connect(ctx.destination);
      oscillator.start(start);
      oscillator.stop(start + NOTE_LENGTH_S);
    });

    window.setTimeout(() => void ctx.close(), CLOSE_AFTER_MS);
  } catch {
    // Audio is optional; the visual confirmation still appears.
  }
}
