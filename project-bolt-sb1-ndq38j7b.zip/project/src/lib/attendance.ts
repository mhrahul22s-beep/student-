export type AttendanceStatus = 'empty' | 'safe' | 'warning' | 'critical';

export const STATUS_META: Record<AttendanceStatus, { label: string; tone: 'teal' | 'amber' | 'rose' | 'slate'; text: string }> = {
  empty: { label: 'No classes yet', tone: 'slate', text: 'text-slate-500' },
  safe: { label: 'On track', tone: 'teal', text: 'text-teal-700' },
  warning: { label: 'At risk', tone: 'amber', text: 'text-amber-700' },
  critical: { label: 'Below target', tone: 'rose', text: 'text-rose-700' },
};

export type AttendanceValidation =
  | { ok: true; attended: number; total: number }
  | { ok: false; errors: { attended?: string; total?: string } };

export function validateAttendanceInput(attendedRaw: string, totalRaw: string): AttendanceValidation {
  const errors: { attended?: string; total?: string } = {};
  const attended = Number(attendedRaw);
  const total = Number(totalRaw);

  if (attendedRaw.trim() === '') {
    errors.attended = 'Enter the number of classes attended.';
  } else if (!Number.isInteger(attended) || attended < 0) {
    errors.attended = 'Use a whole number, 0 or more.';
  }

  if (totalRaw.trim() === '') {
    errors.total = 'Enter the total number of classes held.';
  } else if (!Number.isInteger(total) || total < 1) {
    errors.total = 'Use a whole number, 1 or more.';
  }

  if (!errors.attended && !errors.total && attended > total) {
    errors.attended = `Cannot be more than the ${total} classes held.`;
  }

  if (errors.attended || errors.total) return { ok: false, errors };
  return { ok: true, attended, total };
}

export function parseTarget(raw: string): number | null {
  const value = Number(raw);
  return raw.trim() !== '' && Number.isInteger(value) && value >= 1 && value <= 100 ? value : null;
}

export function attendancePercent(attended: number, total: number): number | null {
  return total > 0 ? (attended / total) * 100 : null;
}

export function getAttendanceStatus(attended: number, total: number, target: number): AttendanceStatus {
  if (total <= 0) return 'empty';
  if (attended * 100 >= target * total) return 'safe';
  if (attended * 100 >= (target - 10) * total) return 'warning';
  return 'critical';
}

// Consecutive classes that must be attended (with no misses) to reach the target.
export function classesNeededToReach(attended: number, total: number, target: number): number | null {
  if (total <= 0) return null;
  if (attended * 100 >= target * total) return 0;
  if (target >= 100) return null;
  return Math.ceil((target * total - 100 * attended) / (100 - target) - 1e-9);
}

// Classes that can be skipped from now on while staying at or above the target.
export function classesCanMiss(attended: number, total: number, target: number): number {
  if (total <= 0 || attended * 100 < target * total) return 0;
  return Math.floor((100 * attended - target * total) / target + 1e-9);
}

function countClasses(count: number): string {
  return `${count} ${count === 1 ? 'class' : 'classes'}`;
}

export function getAttendanceAdvice(attended: number, total: number, target: number): string {
  const status = getAttendanceStatus(attended, total, target);
  if (status === 'empty') return 'Enter your class records to see where you stand.';

  if (status === 'safe') {
    const canMiss = classesCanMiss(attended, total, target);
    return canMiss > 0
      ? `You can miss ${countClasses(canMiss)} and still stay at ${target}% or above.`
      : `You are right at your target. Missing one more class will drop you below ${target}%.`;
  }

  const needed = classesNeededToReach(attended, total, target);
  if (needed === null) return `Reaching ${target}% now requires a perfect attendance record.`;
  return `Attend the next ${countClasses(needed)} without missing any to reach ${target}%.`;
}
