import { addDaysISO } from '@/lib/dates';
import type { AppState } from '@/types';

export function hasSampleRecords(state: AppState): boolean {
  return [...state.tasks, ...state.attendance, ...state.sessions].some(item => item.id.startsWith('seed-'));
}

export function createSampleState(): AppState {
  return {
    targetPercent: 75,
    tasks: [
      { id: 'seed-task-1', title: 'Engineering drawing sheet 3', subject: 'Engineering Graphics', dueDate: addDaysISO(1), priority: 'High', completed: false },
      { id: 'seed-task-2', title: 'Physics lab report: pendulum', subject: 'Engineering Physics', dueDate: addDaysISO(3), priority: 'High', completed: false },
      { id: 'seed-task-3', title: 'Problem set 5: integrals', subject: 'Engineering Mathematics', dueDate: addDaysISO(5), priority: 'Medium', completed: false },
      { id: 'seed-task-4', title: 'Mini project proposal', subject: 'Programming in C', dueDate: addDaysISO(9), priority: 'High', completed: false },
      { id: 'seed-task-5', title: 'Read chapter 4: materials', subject: 'Engineering Materials', dueDate: addDaysISO(0), priority: 'Low', completed: false },
      { id: 'seed-task-6', title: 'Chemistry quiz preparation', subject: 'Engineering Chemistry', dueDate: addDaysISO(-1), priority: 'Medium', completed: false },
      { id: 'seed-task-7', title: 'Workshop safety quiz', subject: 'Workshop Practice', dueDate: addDaysISO(-3), priority: 'Low', completed: true },
      { id: 'seed-task-8', title: 'Lab 2 data sheet', subject: 'Engineering Physics', dueDate: addDaysISO(-2), priority: 'Medium', completed: true },
    ],
    attendance: [
      { id: 'seed-att-1', subject: 'Engineering Mathematics', attended: 18, total: 22 },
      { id: 'seed-att-2', subject: 'Engineering Physics', attended: 15, total: 20 },
      { id: 'seed-att-3', subject: 'Programming in C', attended: 14, total: 16 },
      { id: 'seed-att-4', subject: 'Engineering Graphics', attended: 10, total: 14 },
      { id: 'seed-att-5', subject: 'Engineering Chemistry', attended: 12, total: 18 },
    ],
    sessions: [
      { id: 'seed-ses-1', day: 'Monday', subject: 'Engineering Mathematics', startTime: '18:00', endTime: '19:30' },
      { id: 'seed-ses-2', day: 'Monday', subject: 'Engineering Graphics', startTime: '14:00', endTime: '15:00' },
      { id: 'seed-ses-3', day: 'Tuesday', subject: 'Engineering Physics', startTime: '10:00', endTime: '11:30' },
      { id: 'seed-ses-4', day: 'Wednesday', subject: 'Programming in C', startTime: '16:00', endTime: '17:30' },
      { id: 'seed-ses-5', day: 'Thursday', subject: 'Engineering Chemistry', startTime: '09:00', endTime: '10:00' },
      { id: 'seed-ses-6', day: 'Friday', subject: 'Engineering Mathematics', startTime: '11:00', endTime: '12:00' },
      { id: 'seed-ses-7', day: 'Saturday', subject: 'Engineering Physics', startTime: '10:00', endTime: '12:00' },
      { id: 'seed-ses-8', day: 'Sunday', subject: 'Engineering Graphics', startTime: '17:00', endTime: '18:00' },
    ],
  };
}
