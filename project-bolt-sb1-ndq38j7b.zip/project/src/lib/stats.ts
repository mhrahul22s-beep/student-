import { DAYS, type AppState, type AttendanceRecord, type Day, type StudySession, type Task } from '@/types';
import { daysUntil, sessionHours, timeToMinutes } from '@/lib/dates';

export function getTaskStats(tasks: Task[]) {
  const completed = tasks.filter(task => task.completed).length;
  const overdue = tasks.filter(task => !task.completed && daysUntil(task.dueDate) < 0).length;
  return {
    total: tasks.length,
    completed,
    pending: tasks.length - completed,
    overdue,
    completionRate: tasks.length > 0 ? Math.round((completed / tasks.length) * 100) : 0,
  };
}

export function attendanceTotals(records: AttendanceRecord[]) {
  return records.reduce(
    (sum, record) => ({ attended: sum.attended + record.attended, total: sum.total + record.total }),
    { attended: 0, total: 0 }
  );
}

export function sessionsForDay(sessions: StudySession[], day: Day): StudySession[] {
  return sessions
    .filter(session => session.day === day)
    .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
}

export function weeklyHours(sessions: StudySession[]): Record<Day, number> {
  const hours = Object.fromEntries(DAYS.map(day => [day, 0])) as Record<Day, number>;
  for (const session of sessions) {
    hours[session.day] += sessionHours(session.startTime, session.endTime);
  }
  return hours;
}

export function knownSubjects(state: AppState): string[] {
  const subjects = new Set<string>();
  state.tasks.forEach(task => subjects.add(task.subject));
  state.attendance.forEach(record => subjects.add(record.subject));
  state.sessions.forEach(session => subjects.add(session.subject));
  return [...subjects].sort((a, b) => a.localeCompare(b));
}
