import { createSampleState } from '@/lib/sampleData';
import type { AppState } from '@/types';

const STORAGE_KEY = 'campuspilot-state-v1';

function isAppState(value: unknown): value is AppState {
  if (typeof value !== 'object' || value === null) return false;
  const candidate = value as Partial<AppState>;
  return (
    typeof candidate.targetPercent === 'number' &&
    Array.isArray(candidate.tasks) &&
    Array.isArray(candidate.attendance) &&
    Array.isArray(candidate.sessions)
  );
}

export function loadState(): AppState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : null;
    if (isAppState(parsed)) return parsed;
  } catch {
    // Corrupt data or blocked storage: fall back to sample data below.
  }
  return createSampleState();
}

export function saveState(state: AppState): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Storage may be full or disabled; the app keeps working for this session.
  }
}
