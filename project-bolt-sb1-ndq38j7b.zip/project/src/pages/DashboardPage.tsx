import { useState } from 'react';
import { hasSampleRecords } from '@/lib/sampleData';
import { AlertTriangle, ArrowRight, BookOpen, CalendarDays, CheckCircle2, Clock, ListChecks, RotateCcw, UserCheck, type LucideIcon } from 'lucide-react';
import { Button, Card, EmptyState, ProgressBar } from '@/components/ui';
import { attendancePercent, getAttendanceStatus, STATUS_META } from '@/lib/attendance';
import { formatHours, formatLongDate, formatTime, greeting, todayDay, todayISO } from '@/lib/dates';
import { attendanceTotals, getTaskStats, sessionsForDay, weeklyHours } from '@/lib/stats';
import { DAYS, type AppState, type View } from '@/types';

interface Props {
  state: AppState;
  onNavigate: (view: View) => void;
  onReset: () => void;
}

function StatCard({ label, value, icon: Icon, tone }: { label: string; value: number; icon: LucideIcon; tone: string }) {
  return (
    <Card className="flex items-center gap-4 p-5">
      <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${tone}`}>
        <Icon className="h-5 w-5" />
      </span>
      <div>
        <p className="text-2xl font-bold text-navy-900">{value}</p>
        <p className="text-xs font-medium text-slate-500">{label}</p>
      </div>
    </Card>
  );
}

function SectionHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-5">
      <h2 className="text-lg font-semibold text-navy-900">{title}</h2>
      <p className="text-sm text-slate-500">{subtitle}</p>
    </div>
  );
}

export default function DashboardPage({ state, onNavigate, onReset }: Props) {
  const [now] = useState(() => new Date());
  const showSampleBanner = hasSampleRecords(state);
  const stats = getTaskStats(state.tasks);
  const today = todayISO();
  const todayName = todayDay();
  const todaysSessions = sessionsForDay(state.sessions, todayName);
  const todaysTasks = state.tasks.filter(task => !task.completed && task.dueDate === today);
  const hours = weeklyHours(state.sessions);
  const maxHours = Math.max(1, ...Object.values(hours));
  const totalHours = Object.values(hours).reduce((sum, value) => sum + value, 0);
  const totals = attendanceTotals(state.attendance);
  const overall = attendancePercent(totals.attended, totals.total);
  const overallStatus = getAttendanceStatus(totals.attended, totals.total, state.targetPercent);

  const heroMessage =
    stats.total === 0
      ? 'Add your first assignment to get started.'
      : stats.overdue > 0
        ? `${stats.overdue} overdue ${stats.overdue === 1 ? 'task needs' : 'tasks need'} your attention.`
        : stats.pending === 0
          ? 'Every task is complete. Nice work.'
          : `${stats.pending} ${stats.pending === 1 ? 'task is' : 'tasks are'} still open this week.`;

  return (
    <div className="space-y-6 animate-fade-in">
      {showSampleBanner && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3">
          <p className="text-sm font-medium text-amber-900">
            <span className="mr-2 rounded-full bg-amber-200 px-2 py-0.5 text-xs font-bold uppercase tracking-wide text-amber-900">
              Sample data
            </span>
            These assignments, attendance, and sessions are examples. Reset to start fresh.
          </p>
          <Button variant="secondary" onClick={onReset}>
            <RotateCcw className="h-4 w-4" />
            Reset demo data
          </Button>
        </div>
      )}
      <section className="relative overflow-hidden rounded-2xl bg-navy-900 p-6 text-white shadow-lg sm:p-8">
        <div aria-hidden className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-teal-500/20 blur-3xl" />
        <div className="relative grid gap-6 md:grid-cols-[1fr_auto] md:items-center">
          <div>
            <p className="text-sm font-medium text-teal-300">
              {greeting()}, {formatLongDate(now)}
            </p>
            <h1 className="mt-1 text-2xl font-bold sm:text-3xl">Your week at a glance</h1>
            <p className="mt-2 text-sm text-navy-200">{heroMessage}</p>
            <div className="mt-5 max-w-md">
              <ProgressBar label="Task completion" value={stats.completionRate} tone="teal" track="bg-white/15" />
            </div>
            <p className="mt-2 text-xs text-navy-200">
              {stats.completed} of {stats.total} tasks completed ({stats.completionRate}%)
            </p>
          </div>
          <div className="rounded-xl bg-white/10 p-5 text-center ring-1 ring-white/10 md:min-w-[180px]">
            <p className="text-xs font-semibold uppercase tracking-wider text-navy-200">Overall attendance</p>
            <p className="mt-1 text-3xl font-bold">{overall === null ? '--' : `${overall.toFixed(1)}%`}</p>
            <p className="mt-1 text-xs text-navy-200">
              Target {state.targetPercent}% {overall !== null && `· ${STATUS_META[overallStatus].label}`}
            </p>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total tasks" value={stats.total} icon={ListChecks} tone="bg-navy-100 text-navy-700" />
        <StatCard label="Pending" value={stats.pending} icon={Clock} tone="bg-amber-50 text-amber-700" />
        <StatCard label="Completed" value={stats.completed} icon={CheckCircle2} tone="bg-teal-50 text-teal-700" />
        <StatCard label="Overdue" value={stats.overdue} icon={AlertTriangle} tone="bg-rose-50 text-rose-700" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <SectionHeader
            title="Today's schedule"
            subtitle={`${formatLongDate(now)} · ${todaysSessions.length} study ${todaysSessions.length === 1 ? 'session' : 'sessions'}, ${todaysTasks.length} due`}
          />
          {todaysSessions.length === 0 && todaysTasks.length === 0 ? (
            <EmptyState
              icon={CalendarDays}
              title="Nothing scheduled today"
              description="Plan a study session to fill your day."
              action={
                <Button variant="secondary" onClick={() => onNavigate('planner')}>
                  Open study planner
                  <ArrowRight className="h-4 w-4" />
                </Button>
              }
            />
          ) : (
            <ul className="space-y-3">
              {todaysSessions.map(session => (
                <li key={session.id} className="flex items-center gap-4 rounded-xl bg-slate-50 p-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-teal-100 text-teal-700">
                    <BookOpen className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-navy-900">{session.subject}</p>
                    <p className="text-xs text-slate-500">Study session</p>
                  </div>
                  <p className="whitespace-nowrap text-sm font-medium text-navy-700">
                    {formatTime(session.startTime)} - {formatTime(session.endTime)}
                  </p>
                </li>
              ))}
              {todaysTasks.map(task => (
                <li key={task.id} className="flex items-center gap-4 rounded-xl bg-amber-50/60 p-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-100 text-amber-700">
                    <Clock className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-navy-900">{task.title}</p>
                    <p className="text-xs text-slate-500">{task.subject}</p>
                  </div>
                  <p className="whitespace-nowrap text-sm font-medium text-amber-700">Due today</p>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <SectionHeader title="Attendance" subtitle="Current percentage by subject" />
          {state.attendance.length === 0 ? (
            <EmptyState
              icon={UserCheck}
              title="No attendance yet"
              description="Add a subject to start tracking."
              action={
                <Button variant="secondary" onClick={() => onNavigate('attendance')}>
                  Track attendance
                </Button>
              }
            />
          ) : (
            <ul className="space-y-4">
              {state.attendance.map(record => {
                const percent = attendancePercent(record.attended, record.total);
                const status = getAttendanceStatus(record.attended, record.total, state.targetPercent);
                const meta = STATUS_META[status];
                return (
                  <li key={record.id}>
                    <div className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                      <span className="truncate font-medium text-navy-900">{record.subject}</span>
                      <span className={`whitespace-nowrap font-semibold ${meta.text}`}>
                        {percent === null ? '--' : `${percent.toFixed(1)}%`}
                      </span>
                    </div>
                    <ProgressBar
                      label={`${record.subject} attendance`}
                      value={percent ?? 0}
                      tone={meta.tone}
                    />
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      </div>

      <Card>
        <div className="mb-6 flex flex-wrap items-end justify-between gap-2">
          <SectionHeader title="Study hours this week" subtitle="Planned hours per day from your study planner" />
          <p className="text-sm font-semibold text-navy-700">{formatHours(totalHours)} planned</p>
        </div>
        <div className="grid grid-cols-7 gap-2 sm:gap-4">
          {DAYS.map(day => {
            const value = hours[day];
            const isToday = day === todayName;
            return (
              <div key={day} className="flex flex-col items-center gap-2">
                <span className="text-xs font-medium text-slate-500">{value > 0 ? formatHours(value) : '0h'}</span>
                <div className="flex h-36 w-full items-end rounded-lg bg-slate-100 p-1.5">
                  <div
                    className={`w-full rounded-md transition-all duration-700 ease-out ${isToday ? 'bg-teal-500' : 'bg-navy-500'}`}
                    style={{ height: `${(value / maxHours) * 100}%` }}
                  />
                </div>
                <span className={`text-xs font-semibold ${isToday ? 'text-teal-700' : 'text-slate-500'}`}>{day.slice(0, 3)}</span>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
