import { useState, type FormEvent } from 'react';
import { CalendarDays, Circle, CheckCircle2, ClipboardList, Plus, Trash2 } from 'lucide-react';
import { Button, Card, EmptyState, Field, PriorityBadge, inputClass } from '@/components/ui';
import { daysUntil, formatDueDate } from '@/lib/dates';
import { PRIORITIES, type Priority, type Task, type TaskInput } from '@/types';

type Filter = 'all' | 'pending' | 'completed';

const FILTERS: { value: Filter; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'pending', label: 'Pending' },
  { value: 'completed', label: 'Completed' },
];

interface TaskForm {
  title: string;
  subject: string;
  dueDate: string;
  priority: Priority;
}

type TaskFormErrors = Partial<Record<keyof TaskForm, string>>;

const EMPTY_FORM: TaskForm = { title: '', subject: '', dueDate: '', priority: 'Medium' };

function validateTaskForm(form: TaskForm): TaskFormErrors {
  const errors: TaskFormErrors = {};
  const title = form.title.trim();
  if (!title) errors.title = 'Enter a task title.';
  else if (title.length > 80) errors.title = 'Keep the title under 80 characters.';
  if (!form.subject.trim()) errors.subject = 'Enter the subject this task belongs to.';
  if (!form.dueDate) errors.dueDate = 'Pick a due date.';
  return errors;
}

function dueLabel(task: Task): { text: string; className: string } | null {
  if (task.completed) return null;
  const days = daysUntil(task.dueDate);
  if (days < 0) {
    const overdueBy = Math.abs(days);
    return { text: `Overdue by ${overdueBy} ${overdueBy === 1 ? 'day' : 'days'}`, className: 'font-semibold text-rose-600' };
  }
  if (days === 0) return { text: 'Due today', className: 'font-semibold text-amber-700' };
  if (days === 1) return { text: 'Due tomorrow', className: 'text-slate-600' };
  return { text: `In ${days} days`, className: 'text-slate-600' };
}

interface Props {
  tasks: Task[];
  subjects: string[];
  onAdd: (input: TaskInput) => void;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function AssignmentsPage({ tasks, subjects, onAdd, onToggle, onDelete }: Props) {
  const [form, setForm] = useState<TaskForm>(EMPTY_FORM);
  const [errors, setErrors] = useState<TaskFormErrors>({});
  const [filter, setFilter] = useState<Filter>('all');

  const updateField = <K extends keyof TaskForm>(key: K, value: TaskForm[K]) => {
    setForm(prev => ({ ...prev, [key]: value }));
    setErrors(prev => ({ ...prev, [key]: undefined }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validateTaskForm(form);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    onAdd({
      title: form.title.trim(),
      subject: form.subject.trim(),
      dueDate: form.dueDate,
      priority: form.priority,
    });
    setForm(EMPTY_FORM);
  };

  const pendingTasks = tasks
    .filter(task => !task.completed)
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const completedTasks = tasks
    .filter(task => task.completed)
    .sort((a, b) => b.dueDate.localeCompare(a.dueDate));

  const visibleTasks =
    filter === 'pending' ? pendingTasks : filter === 'completed' ? completedTasks : [...pendingTasks, ...completedTasks];

  const emptyMessage =
    tasks.length === 0
      ? { title: 'No assignments yet', description: 'Add your first assignment using the form.' }
      : filter === 'pending'
        ? { title: 'All caught up', description: 'You have no pending assignments.' }
        : { title: 'Nothing completed yet', description: 'Completed assignments will appear here.' };

  return (
    <div className="grid gap-6 animate-fade-in lg:grid-cols-3">
      <Card className="h-fit lg:col-span-1">
        <h1 className="text-xl font-bold text-navy-900">Add assignment</h1>
        <p className="mb-5 mt-1 text-sm text-slate-500">Capture deadlines so nothing slips past you.</p>
        <form onSubmit={handleSubmit} noValidate className="space-y-4">
          <Field label="Task title" htmlFor="task-title" error={errors.title}>
            <input
              id="task-title"
              className={inputClass}
              placeholder="e.g. Thermodynamics assignment 2"
              value={form.title}
              onChange={event => updateField('title', event.target.value)}
              aria-invalid={Boolean(errors.title)}
            />
          </Field>
          <Field label="Subject" htmlFor="task-subject" error={errors.subject}>
            <input
              id="task-subject"
              list="subject-options"
              className={inputClass}
              placeholder="e.g. Engineering Physics"
              value={form.subject}
              onChange={event => updateField('subject', event.target.value)}
              aria-invalid={Boolean(errors.subject)}
            />
            <datalist id="subject-options">
              {subjects.map(subject => (
                <option key={subject} value={subject} />
              ))}
            </datalist>
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Due date" htmlFor="task-due" error={errors.dueDate}>
              <input
                id="task-due"
                type="date"
                className={inputClass}
                value={form.dueDate}
                onChange={event => updateField('dueDate', event.target.value)}
                aria-invalid={Boolean(errors.dueDate)}
              />
            </Field>
            <Field label="Priority" htmlFor="task-priority">
              <select
                id="task-priority"
                className={inputClass}
                value={form.priority}
                onChange={event => updateField('priority', event.target.value as Priority)}
              >
                {PRIORITIES.map(priority => (
                  <option key={priority} value={priority}>
                    {priority}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <Button type="submit" className="w-full">
            <Plus className="h-4 w-4" />
            Add assignment
          </Button>
        </form>
      </Card>

      <Card className="lg:col-span-2">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-navy-900">Your assignments</h2>
            <p className="text-sm text-slate-500">
              {pendingTasks.length} pending · {completedTasks.length} completed
            </p>
          </div>
          <div role="tablist" aria-label="Filter assignments" className="inline-flex rounded-xl bg-slate-100 p-1">
            {FILTERS.map(option => (
              <button
                key={option.value}
                type="button"
                role="tab"
                aria-selected={filter === option.value}
                onClick={() => setFilter(option.value)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition sm:text-sm ${
                  filter === option.value ? 'bg-white text-navy-900 shadow-sm' : 'text-slate-600 hover:text-navy-900'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {visibleTasks.length === 0 ? (
          <EmptyState icon={ClipboardList} title={emptyMessage.title} description={emptyMessage.description} />
        ) : (
          <ul className="space-y-3">
            {visibleTasks.map(task => {
              const due = dueLabel(task);
              return (
                <li
                  key={task.id}
                  className="group flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4 transition duration-200 hover:border-teal-200 hover:shadow-md"
                >
                  <button
                    type="button"
                    onClick={() => onToggle(task.id)}
                    aria-label={task.completed ? 'Mark as pending' : 'Mark as complete'}
                    className="mt-0.5 shrink-0 rounded-full transition hover:scale-110 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-teal-500/30"
                  >
                    {task.completed ? (
                      <CheckCircle2 className="h-6 w-6 text-teal-600" />
                    ) : (
                      <Circle className="h-6 w-6 text-slate-300 group-hover:text-teal-500" />
                    )}
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className={`font-semibold ${task.completed ? 'text-slate-400 line-through' : 'text-navy-900'}`}>
                      {task.title}
                    </p>
                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                      <span>{task.subject}</span>
                      <span className="inline-flex items-center gap-1">
                        <CalendarDays className="h-3.5 w-3.5" />
                        {formatDueDate(task.dueDate)}
                      </span>
                      {due && <span className={due.className}>{due.text}</span>}
                    </div>
                  </div>
                  <PriorityBadge priority={task.priority} />
                  <button
                    type="button"
                    onClick={() => onDelete(task.id)}
                    aria-label="Delete assignment"
                    className="shrink-0 rounded-lg p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
