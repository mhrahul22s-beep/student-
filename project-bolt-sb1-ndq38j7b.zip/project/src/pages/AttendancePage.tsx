import { useState, type FormEvent } from 'react';
import { Pencil, Plus, Trash2, UserCheck } from 'lucide-react';
import AttendanceCalculator from '@/components/AttendanceCalculator';
import AttendanceSubjectForm from '@/components/AttendanceSubjectForm';
import { Button, Card, EmptyState, Field, Modal, ProgressBar, inputClass } from '@/components/ui';
import {
  attendancePercent,
  getAttendanceAdvice,
  getAttendanceStatus,
  parseTarget,
  STATUS_META,
} from '@/lib/attendance';
import { attendanceTotals } from '@/lib/stats';
import type { AttendanceInput, AttendanceRecord } from '@/types';

interface Props {
  records: AttendanceRecord[];
  subjects: string[];
  target: number;
  onSave: (id: string | null, input: AttendanceInput) => void;
  onDelete: (id: string) => void;
  onTargetChange: (value: number) => void;
}

type Editor = null | 'new' | AttendanceRecord;

function TargetCard({ target, onSave }: { target: number; onSave: (value: number) => void }) {
  const [draft, setDraft] = useState(String(target));
  const [error, setError] = useState<string>();

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const value = parseTarget(draft);
    if (value === null) {
      setError('Enter a whole number from 1 to 100.');
      return;
    }
    setError(undefined);
    onSave(value);
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} noValidate>
        <Field label="Target attendance (%)" htmlFor="target-input" error={error}>
          <div className="flex gap-2">
            <input
              id="target-input"
              type="number"
              inputMode="numeric"
              min={1}
              max={100}
              className={inputClass}
              value={draft}
              onChange={event => {
                setDraft(event.target.value);
                setError(undefined);
              }}
            />
            <Button type="submit" variant="secondary">
              Save
            </Button>
          </div>
        </Field>
        <p className="mt-2 text-xs text-slate-500">Most colleges require 75%. Changing this updates every subject.</p>
      </form>
    </Card>
  );
}

function SubjectCard({
  record,
  target,
  onEdit,
  onDelete,
}: {
  record: AttendanceRecord;
  target: number;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const percent = attendancePercent(record.attended, record.total);
  const status = getAttendanceStatus(record.attended, record.total, target);
  const meta = STATUS_META[status];

  return (
    <Card className="transition duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate font-semibold text-navy-900">{record.subject}</h3>
          <p className="text-xs text-slate-500">
            {record.attended} attended of {record.total} held
          </p>
        </div>
        <div className="flex shrink-0 gap-1">
          <button
            type="button"
            onClick={onEdit}
            aria-label={`Edit ${record.subject}`}
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-navy-900"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            aria-label={`Delete ${record.subject}`}
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
      <div className="mt-4 flex items-end justify-between">
        <p className="text-2xl font-bold text-navy-900">{percent === null ? '--' : `${percent.toFixed(1)}%`}</p>
        <p className={`text-xs font-semibold ${meta.text}`}>{meta.label}</p>
      </div>
      <div className="mt-2">
        <ProgressBar label={`${record.subject} attendance`} value={percent ?? 0} tone={meta.tone} />
      </div>
      <p className="mt-3 text-sm leading-relaxed text-slate-600">
        {getAttendanceAdvice(record.attended, record.total, target)}
      </p>
    </Card>
  );
}

export default function AttendancePage({ records, subjects, target, onSave, onDelete, onTargetChange }: Props) {
  const [editor, setEditor] = useState<Editor>(null);
  const totals = attendanceTotals(records);
  const overall = attendancePercent(totals.attended, totals.total);
  const overallStatus = getAttendanceStatus(totals.attended, totals.total, target);
  const editing = editor && editor !== 'new' ? editor : null;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-navy-900">Attendance</h1>
        <p className="text-sm text-slate-500">Track each subject and see exactly how many classes you need.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Overall attendance</p>
          <div className="mt-2 flex flex-wrap items-end justify-between gap-2">
            <p className="text-4xl font-bold text-navy-900">{overall === null ? '--' : `${overall.toFixed(1)}%`}</p>
            <p className={`text-sm font-semibold ${STATUS_META[overallStatus].text}`}>
              {STATUS_META[overallStatus].label}
            </p>
          </div>
          <div className="mt-4">
            <ProgressBar
              label="Overall attendance"
              value={overall ?? 0}
              tone={STATUS_META[overallStatus].tone}
            />
          </div>
          <p className="mt-3 text-xs text-slate-500">
            {totals.attended} of {totals.total} classes attended across {records.length}{' '}
            {records.length === 1 ? 'subject' : 'subjects'}
          </p>
        </Card>
        <TargetCard key={target} target={target} onSave={onTargetChange} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <AttendanceCalculator target={target} />

        <div className="space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-navy-900">Your subjects</h2>
            <Button onClick={() => setEditor('new')}>
              <Plus className="h-4 w-4" />
              Add subject
            </Button>
          </div>

          {records.length === 0 ? (
            <EmptyState
              icon={UserCheck}
              title="No subjects tracked yet"
              description="Add a subject with the classes you have attended so far."
              action={
                <Button variant="secondary" onClick={() => setEditor('new')}>
                  Add your first subject
                </Button>
              }
            />
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {records.map(record => (
                <SubjectCard
                  key={record.id}
                  record={record}
                  target={target}
                  onEdit={() => setEditor(record)}
                  onDelete={() => onDelete(record.id)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <Modal
        open={editor !== null}
        title={editing ? 'Edit subject' : 'Add subject'}
        onClose={() => setEditor(null)}
      >
        <AttendanceSubjectForm
          key={editing ? editing.id : 'new'}
          initial={editing}
          subjects={subjects}
          onCancel={() => setEditor(null)}
          onSubmit={input => {
            onSave(editing ? editing.id : null, input);
            setEditor(null);
          }}
        />
      </Modal>
    </div>
  );
}
