import { useState, type FormEvent } from 'react';
import { CalendarDays, Clock, Plus, Trash2 } from 'lucide-react';
import { Button, Card, EmptyState, Field, inputClass } from '@/components/ui';
import { formatHours, formatTime, sessionHours, timeToMinutes, todayDay } from '@/lib/dates';
import { sessionsForDay, weeklyHours } from '@/lib/stats';
import { DAYS, type Day, type SessionInput, type StudySession } from '@/types';

interface SessionForm {
  day: Day;
  subject: string;
  startTime: string;
  endTime: string;
}

type SessionErrors = Partial<Record<keyof SessionForm, string>>;

function validateSessionForm(form: SessionForm): SessionErrors {
  const errors: SessionErrors = {};
  if (!form.subject.trim()) errors.subject = 'Enter the subject you will study.';
  if (!form.startTime) errors.startTime = 'Pick a start time.';
  if (!form.endTime) errors.endTime = 'Pick an end time.';
  else if (form.startTime && timeToMinutes(form.endTime) <= timeToMinutes(form.startTime)) {
    errors.endTime = 'End time must be after the start time.';
  }
  return errors;
}

interface Props {
  sessions: StudySession[];
  subjects: string[];
  onAdd: (input: SessionInput) => void;
  onDelete: (id: string) => void;
}

export default function PlannerPage({ sessions, subjects, onAdd, onDelete }: Props) {
  const [form, setForm] = useState<SessionForm>(() => ({
    day: todayDay(),
    subject: '',
    startTime: '',
    endTime: '',
  }));
  const [errors, setErrors] = useState<SessionErrors>({});
  const hours = weeklyHours(sessions);
  const totalHours = Object.values(hours).reduce((sum, value) => sum + value, 0);
  const todayName = todayDay();

  const updateField = <K extends keyof SessionForm>(key: K, value: SessionForm[K]) => {
    setForm(prev => ({ ...prev, [key]: value }));
    setErrors(prev => ({ ...prev, [key]: undefined }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validateSessionForm(form);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    onAdd({
      day: form.day,
      subject: form.subject.trim(),
      startTime: form.startTime,
      endTime: form.endTime,
    });
    setForm(prev => ({ ...prev, subject: '', startTime: '', endTime: '' }));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Weekly study planner</h1>
          <p className="text-sm text-slate-500">
            {sessions.length} {sessions.length === 1 ? 'session' : 'sessions'} planned · {formatHours(totalHours)} this week
          </p>
        </div>
      </div>

      <Card>
        <h2 className="mb-5 text-lg font-semibold text-navy-900">Add study session</h2>
        <form onSubmit={handleSubmit} noValidate className="grid gap-4 md:grid-cols-2 xl:grid-cols-[1fr_1.5fr_1fr_1fr_auto] xl:items-start">
          <Field label="Day" htmlFor="session-day">
            <select
              id="session-day"
              className={inputClass}
              value={form.day}
              onChange={event => updateField('day', event.target.value as Day)}
            >
              {DAYS.map(day => (
                <option key={day} value={day}>
                  {day}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Subject" htmlFor="session-subject" error={errors.subject}>
            <input
              id="session-subject"
              list="session-subject-options"
              className={inputClass}
              placeholder="e.g. Engineering Mathematics"
              value={form.subject}
              onChange={event => updateField('subject', event.target.value)}
            />
            <datalist id="session-subject-options">
              {subjects.map(subject => (
                <option key={subject} value={subject} />
              ))}
            </datalist>
          </Field>
          <Field label="Start" htmlFor="session-start" error={errors.startTime}>
            <input
              id="session-start"
              type="time"
              className={inputClass}
              value={form.startTime}
              onChange={event => updateField('startTime', event.target.value)}
            />
          </Field>
          <Field label="End" htmlFor="session-end" error={errors.endTime}>
            <input
              id="session-end"
              type="time"
              className={inputClass}
              value={form.endTime}
              onChange={event => updateField('endTime', event.target.value)}
            />
          </Field>
          <div className="flex items-end md:col-span-2 xl:col-span-1">
            <Button type="submit" className="w-full xl:w-auto">
              <Plus className="h-4 w-4" />
              Add
            </Button>
          </div>
        </form>
      </Card>

      {sessions.length === 0 && (
        <EmptyState
          icon={CalendarDays}
          title="Your week is open"
          description="Add a study session above to start building your weekly plan."
        />
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {DAYS.map(day => {
          const daySessions = sessionsForDay(sessions, day);
          const isToday = day === todayName;
          return (
            <Card
              key={day}
              className={`flex flex-col p-4 ${isToday ? 'ring-2 ring-teal-400' : ''}`}
            >
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-navy-900">{day}</h3>
                  {isToday && <p className="text-xs font-semibold text-teal-700">Today</p>}
                </div>
                <span className="text-xs font-medium text-slate-500">{formatHours(hours[day])}</span>
              </div>
              {daySessions.length === 0 ? (
                <p className="rounded-lg bg-slate-50 px-3 py-4 text-center text-xs text-slate-400">No sessions</p>
              ) : (
                <ul className="space-y-2">
                  {daySessions.map(session => (
                    <li
                      key={session.id}
                      className="group rounded-lg border-l-4 border-teal-500 bg-teal-50/60 p-3 transition hover:shadow-sm"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className="truncate text-sm font-semibold text-navy-900">{session.subject}</p>
                        <button
                          type="button"
                          onClick={() => onDelete(session.id)}
                          aria-label={`Delete ${session.subject} session on ${day}`}
                          className="shrink-0 rounded-md p-1 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <p className="mt-1 flex items-center gap-1 text-xs text-slate-600">
                        <Clock className="h-3 w-3" />
                        {formatTime(session.startTime)} - {formatTime(session.endTime)}
                        <span className="text-slate-400">· {formatHours(sessionHours(session.startTime, session.endTime))}</span>
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
